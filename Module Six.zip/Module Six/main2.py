import numpy as np
import matplotlib.pyplot as plt

# Simulated training and validation accuracies for overfitting, underfitting, and optimal model
epochs = np.arange(1, 21)

# Underfitting: both training and validation accuracy remain low
train_acc_underfit = np.linspace(0.4, 0.6, 20)
val_acc_underfit = np.linspace(0.3, 0.55, 20)

# Overfitting: training accuracy improves significantly, but validation accuracy plateaus
train_acc_overfit = np.linspace(0.5, 0.99, 20)
val_acc_overfit = np.concatenate([np.linspace(0.5, 0.7, 10), np.linspace(0.69, 0.55, 10)])

# Optimal fit: both training and validation accuracy improve and converge
train_acc_optimal = np.linspace(0.5, 0.95, 20)
val_acc_optimal = np.linspace(0.45, 0.93, 20)

# Plotting
plt.figure(figsize=(10, 6))

# Underfitting
plt.subplot(1, 3, 1)
plt.plot(epochs, train_acc_underfit, label='Training Accuracy', color='blue')
plt.plot(epochs, val_acc_underfit, label='Validation Accuracy', color='orange')
plt.title("Underfitting")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.ylim(0, 1)
plt.legend()

# Overfitting
plt.subplot(1, 3, 2)
plt.plot(epochs, train_acc_overfit, label='Training Accuracy', color='blue')
plt.plot(epochs, val_acc_overfit, label='Validation Accuracy', color='orange')
plt.title("Overfitting")
plt.xlabel("Epochs")
plt.ylim(0, 1)

# Optimal fit
plt.subplot(1, 3, 3)
plt.plot(epochs, train_acc_optimal, label='Training Accuracy', color='blue')
plt.plot(epochs, val_acc_optimal, label='Validation Accuracy', color='orange')
plt.title("Optimal Fit")
plt.xlabel("Epochs")
plt.ylim(0, 1)

plt.tight_layout()
plt.show()
